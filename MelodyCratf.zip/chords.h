#ifndef CHORDS_H
#define CHORDS_H

int chord_to_notes(const char* chord, int* notes);

#endif // CHORDS_H
